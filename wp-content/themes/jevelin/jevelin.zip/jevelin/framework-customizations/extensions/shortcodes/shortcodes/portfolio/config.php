<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Portfolio', 'jevelin' ),
	'description' => esc_html__( 'Add a Portfolio', 'jevelin' ),
	'tab'         => esc_html__( 'Content Elements', 'jevelin' ),
	'popup_size'  => 'medium',
	'icon' => 'ti-gallery',
    'title_template' => '
        <b>{{- htmlDecode(title) }}</b>
    	<div class="sh-builder-item-desc">

            {{ if( typeof o.columns != "undefined" && o.columns ) { }}
                {{- o.columns }} columns
            {{ } }}

    	</div>',
);
